export const YOUTUBE_API_KEY = 'AIzaSyAvIdFZg2O4Gz2vchxpUnfjhKXMZFPyykg';
// export const YOUTUBE_API_KEY = 'AIzaSyBs75e9drcGF3-wh3kLpEG37Lx6ogWK3U4'; 오류남
