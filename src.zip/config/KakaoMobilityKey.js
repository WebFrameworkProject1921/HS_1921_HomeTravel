export const KAKAO_MOBILITY_API_KEY = '2813bf9a54685d4a5eeb78d8a85b58ba'; //카카오 모빌리티 API 키
