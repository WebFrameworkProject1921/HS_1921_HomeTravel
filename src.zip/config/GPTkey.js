export const GPT_API_KEY =
  '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';
